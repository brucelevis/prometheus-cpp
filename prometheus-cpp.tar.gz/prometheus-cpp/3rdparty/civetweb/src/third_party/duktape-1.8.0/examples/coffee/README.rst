=====================
Coffeescript examples
=====================

A few tests to see how CoffeeScript works with Duktape.  Just convert the
Coffeescript files to Javascript with the ``Makefile.coffee`` in the
distributable, or manually::

  $ coffee -c hello.coffee
  $ cat hello.js
