===========================
Duktape guide example files
===========================

Examples used in the Duktape guide.
